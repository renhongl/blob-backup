'use strict';
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import Index from './component/index/index.jsx';
import Observer from './core/Observer';

ReactDOM.render(
    <Index />,
    document.getElementById('container')
)